#!/usr/bin/python

from __future__ import (absolute_import, division, print_function)
from OpenSSL.crypto import verify
__metaclass__ = type

# DOCUMENTATION = r'''
# ---
# module: azdo_agent

# short_description: Manages Azure DevOps agents

# version_added: "1.0.0"

# description: Manages Azure DevOps agents

# author:
#     - Eduardo Lucas (eduardo.lucas@ictu.nl)
# '''

from ansible.module_utils.basic import AnsibleModule
from azure.devops.v6_0.task_agent.task_agent_client import TaskAgentClient
from msrest.authentication import BasicAuthentication

result = dict(
    changed=False,
    agent=None,
    pool=None,
    message='',
    agent_enabled=None,
    agent_pool_name=None
)


def run_module():

    module_args = dict(
        name=dict(type='str', required=True),
        state=dict(type='str', required=True),
        pat=dict(type='str', required=True),
        url=dict(type='str', required=True),
    )

    module = AnsibleModule(
        argument_spec=module_args,
        supports_check_mode=True
    )

    if module.check_mode:
        module.exit_json(**result)

    personal_access_token = module.params['pat']
    organization_url = module.params['url']
    credentials = BasicAuthentication('', personal_access_token)
    client = TaskAgentClient(base_url=organization_url, creds=credentials)
    client.config.connection.verify = False

    agent_and_pool = get_agent(client, module.params['name'])

    result['message'] = result['message'] + " >>> result = " + str(agent_and_pool)
    
    if (agent_and_pool and agent_and_pool['pool']):
      result['agent_pool_name'] = agent_and_pool['pool'].name

    if agent_and_pool and agent_and_pool['agent'] and agent_and_pool['pool']:
        result['message'] = "Agent enabled is " + \
            str(agent_and_pool['agent'].enabled) + \
            " and desired state is " + str(module.params['state'])
        
        # Disable the agent when enabled and desired state = disabled
        if agent_and_pool['agent'].enabled and module.params['state'] == 'disabled':
            result['agent_enabled'] = 'disabled'
            set_agent_enabled(client,
                              agent_and_pool['agent'], agent_and_pool['pool'], False)
        else:

          # Disable the agent when disabled and desired state = enabled
          if not agent_and_pool['agent'].enabled and module.params['state'] == 'enabled':
              result['agent_enabled'] = 'enabled'
              set_agent_enabled(client,
                                agent_and_pool['agent'], agent_and_pool['pool'], True)
          
          else:
            
            result['agent_enabled'] = agent_and_pool['agent'].enabled
        
        result['agent'] = str(agent_and_pool['agent'])
        result['pool'] = str(agent_and_pool['pool'])

    module.exit_json(**result)

def get_agent(client, agent_name):
    agent_and_pool_result = dict(pool=None, agent=None)
    client.config.connection.verify = False
    pools = client.get_agent_pools()
    for pool in pools:
        pool_agents = client.get_agents(pool_id=pool.id)
        for pool_agent in pool_agents:
            if pool_agent.name == agent_name:
                pool_agent_details = client.get_agent(
                    pool_id=pool.id, agent_id=pool_agent.id, include_capabilities=None, include_assigned_request=True, include_last_completed_request=True, property_filters=None)
                agent_and_pool_result = dict(pool=pool, agent=pool_agent_details)
                result['message'] = result['message'] + '>>> found agent'
                break
        # if agent_and_pool_result.pool:
        #     break

    return agent_and_pool_result


def set_agent_enabled(client, agent, pool, enabled):
    agent.enabled = enabled
    client.update_agent(agent, pool.id, agent.id)
    result["message"] = result["message"] + \
        ('\r\n*** updating agent ***' + str(agent))
    return


def main():
    run_module()


if __name__ == '__main__':
    main()
